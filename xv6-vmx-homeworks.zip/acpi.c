/* acpi.c 
 *
 * Copyright (c) 2013 Brian Swetland
 * 
 * Permission is hereby granted, free of charge, to any person obtaining
 * a copy of this software and associated documentation files (the
 * "Software"), to deal in the Software without restriction, including
 * without limitation the rights to use, copy, modify, merge, publish,
 * distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so, subject to
 * the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION
 * WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 */

#include "types.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mp.h"
#include "x86.h"
#include "mmu.h"
#include "proc.h"
#include "acpi.h"

extern struct cpu cpus[NCPU];
extern int ncpu;
extern uchar ioapicid;

static struct acpi_rdsp *
scan_rdsp(uint64 base, uint len)
{
  uchar *p;
  for (p = P2V(base); len >= sizeof(struct acpi_rdsp); len -= 4, p += 4) {
    if (memcmp(p, SIG_RDSP, 8) == 0) {
      uint sum, n;
      for (sum = 0, n = 0; n < 20; n++)
        sum += p[n];
      if ((sum & 0xff) == 0)
        return (struct acpi_rdsp *) p;
    }
  }
  return (struct acpi_rdsp *) 0;  
}

static struct acpi_rdsp *
find_rdsp(void)
{
  struct acpi_rdsp *rdsp;
  uint64 pa;
  pa = *((ushort*) P2V(0x40E)) << 4; // EBDA
  if (pa && (rdsp = scan_rdsp(pa, 1024)))
    return rdsp;
  return scan_rdsp(0xE0000, 0x20000);
} 

static int
acpi_config_smp(struct acpi_madt *madt) {
  uint32 lapic_addr;
  uint nioapic = 0;
  uchar *p, *e;

  if (!madt)
    return 0;
  if (madt->header.length < sizeof(struct acpi_madt))
    return 0;

  lapic_addr = madt->lapic_addr_phys;

  p = madt->table;
  e = p + madt->header.length - sizeof(struct acpi_madt);

  while (p < e) {
    uint len;
    if ((e - p) < 2)
      break;
    len = p[1];
    if ((e - p) < len)
      break;
    switch (p[0]) {
    case TYPE_LAPIC: {
      struct madt_lapic *lapic = (void*) p;
      if (len < sizeof(*lapic))
        break;
      if (!(lapic->flags & APIC_LAPIC_ENABLED))
        break;
      cpus[ncpu].apicid = lapic->apic_id;
      ncpu++;
      break;
    }
    case TYPE_IOAPIC: {
      struct madt_ioapic *ioapic = (void*) p;
      if (len < sizeof(*ioapic))
        break;
      if (nioapic) {
        cprintf("warning: multiple ioapics are not supported");
      } else {
        ioapicid = ioapic->id;
      }
      nioapic++;
      break;
    }
    }
    p += len;
  }

  if (ncpu) {
    lapic = DEV_P2V(((uint64)lapic_addr));
    return 1;
  }

  return 0;
}

// Return a boolean indicating the success of MP initialization 
// using ACPI tables
int
acpiinit(void)
{
  unsigned n, count;
  struct acpi_rdsp *rdsp;
  struct acpi_rsdt *rsdt;
  struct acpi_madt *madt = 0;

  rdsp = find_rdsp();
  if (!rdsp)
    return 0;
  rsdt = acpitable((uint64)rdsp->rsdt_addr_phys);
  if (!rsdt)
    return 0;
  count = (rsdt->header.length - sizeof(*rsdt)) / 4;
  for (n = 0; n < count; n++) {
    struct acpi_desc_header *hdr = acpitable((uint64)rsdt->entry[n]);
    if (!hdr)
      return 0;
    if (!memcmp(hdr->signature, SIG_MADT, 4))
      madt = (void*) hdr;
  }

  return acpi_config_smp(madt);
}
